
const Home = () => {
    return (
        <div className="pt-24 pb-12">
            <h1>This is student home</h1>
        </div>
    );
};

export default Home;